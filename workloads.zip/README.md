# KEY

```
filename = {mode}-{operations}-{size}.txt

mode = {i (increasing), d (decreasing), u (unordered), c (chaotic)}
operations = {i (insert), a (all)}
size = {sm (100), md (1000), lg (10000)}
```
local